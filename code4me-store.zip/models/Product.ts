import { Schema, model, models } from 'mongoose';

const ProductSchema = new Schema({
  title: { type: String, required: true },
  slug: { type: String, required: true, unique: true },
  category: { type: String, enum: ['accounts','programs','tools'], required: true },
  priceUSD: { type: Number, required: true },
  description: { type: String, default: '' },
  productInfo: { type: String, default: '' },
  fileFormat: { type: String, default: '' },
  recommendations: { type: String, default: '' },
  images: [{ type: String }],
  stockType: { type: String, enum: ['accounts','file'], required: true },
  downloadableUrl: { type: String, default: '' }, // for programs/tools
  createdAt: { type: Date, default: Date.now },
});

export default models.Product || model('Product', ProductSchema);
