import { Schema, model, models } from 'mongoose';

const StockItemSchema = new Schema({
  productSlug: { type: String, index: true, required: true },
  value: { type: String, required: true }, // e.g., username:password
  used: { type: Boolean, default: false, index: true },
  createdAt: { type: Date, default: Date.now },
});

export default models.StockItem || model('StockItem', StockItemSchema);
