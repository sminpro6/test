import { Schema, model, models } from 'mongoose';

const OrderSchema = new Schema({
  items: [{
    productSlug: String,
    title: String,
    quantity: Number,
    unitPriceUSD: Number,
  }],
  totalUSD: Number,
  status: { type: String, enum: ['pending','paid','fulfilled','cancelled'], default: 'pending' },
  txHash: { type: String, default: '' },
  email: { type: String, default: '' },
  deliveredData: { type: String, default: '' }, // accounts blob or download link
  createdAt: { type: Date, default: Date.now },
});

export default models.Order || model('Order', OrderSchema);
