import { ethers } from 'ethers';

const USDT_CONTRACT = process.env.USDT_CONTRACT ?? '0xdAC17F958D2ee523a2206206994597C13D831ec7';
const USDT_ADDRESS = (process.env.USDT_ADDRESS ?? '').toLowerCase();
const ETH_PROVIDER_URL = process.env.ETH_PROVIDER_URL!;

// Minimal ERC20 ABI
const abi = [
  'function decimals() view returns (uint8)',
  'function balanceOf(address) view returns (uint256)',
  'event Transfer(address indexed from, address indexed to, uint256 value)'
];

export async function verifyUsdtPaymentByTx(txHash: string, expectedAmount: number): Promise<{ok:boolean, amount:number, from?:string}> {
  const provider = new ethers.JsonRpcProvider(ETH_PROVIDER_URL);
  const receipt = await provider.getTransactionReceipt(txHash);
  if (!receipt || receipt.status !== 1n) return { ok:false, amount:0 };
  const iface = new ethers.Interface(abi);
  let paid = 0;
  let from: string | undefined;
  for (const log of receipt.logs) {
    if (log.address.toLowerCase() !== USDT_CONTRACT.toLowerCase()) continue;
    try {
      const parsed = iface.parseLog({ topics: log.topics as string[], data: log.data });
      if (parsed?.name === 'Transfer') {
        const to = parsed.args[1] as string;
        if (to.toLowerCase() === USDT_ADDRESS) {
          const value = Number(parsed.args[2]) / 1e6; // USDT 6 decimals
          paid += value;
          from = parsed.args[0] as string;
        }
      }
    } catch {}
  }
  return { ok: paid >= expectedAmount, amount: paid, from };
}
