import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { cookies } from 'next/headers';

const ADMIN_EMAIL = process.env.ADMIN_EMAIL!;
const ADMIN_PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH!;
const JWT_SECRET = process.env.JWT_SECRET!;

export async function login(email: string, password: string) {
  if (email !== ADMIN_EMAIL) return null;
  const ok = await bcrypt.compare(password, ADMIN_PASSWORD_HASH);
  if (!ok) return null;
  const token = jwt.sign({ role: 'admin', email }, JWT_SECRET, { expiresIn: '7d' });
  cookies().set('admin_token', token, { httpOnly: true, secure: true, sameSite: 'lax', maxAge: 60*60*24*7, path: '/' });
  return { token };
}

export function requireAdminToken(): boolean {
  const c = cookies().get('admin_token');
  if (!c) return false;
  try { jwt.verify(c.value, JWT_SECRET); return true; } catch { return false; }
}

export function logout() {
  cookies().set('admin_token', '', { maxAge: 0, path: '/' });
}
