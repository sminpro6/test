import Link from 'next/link'

export function ProductCard({ p }:{ p:any }){
  return (
    <div className="card">
      <div className="aspect-video bg-zinc-800 rounded-xl mb-3"></div>
      <h3 className="font-semibold">{p.title}</h3>
      <div className="text-zinc-400 text-sm capitalize">{p.category}</div>
      <div className="mt-2 font-bold">${p.priceUSD.toFixed(2)}</div>
      <Link className="btn mt-3 w-full" href={`/product/${p.slug}`}>View</Link>
    </div>
  )
}
