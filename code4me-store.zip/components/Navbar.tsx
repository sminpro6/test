'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { LanguageSwitcher } from './LanguageSwitcher'

export default function Navbar(){
  const pathname = usePathname()
  return (
    <header className="border-b border-zinc-800">
      <div className="container flex items-center justify-between h-16">
        <Link href="/" className="font-bold text-xl">code4me</Link>
        <nav className="flex gap-4">
          <Link className={pathname?.startsWith('/catalog')?'text-white':'text-zinc-300 hover:text-white'} href="/catalog">Catalog</Link>
          <Link className={pathname?.startsWith('/contact')?'text-white':'text-zinc-300 hover:text-white'} href="/contact">Contact</Link>
          <Link className={pathname?.startsWith('/cart')?'text-white':'text-zinc-300 hover:text-white'} href="/cart">Cart</Link>
          <LanguageSwitcher />
        </nav>
      </div>
    </header>
  )
}
