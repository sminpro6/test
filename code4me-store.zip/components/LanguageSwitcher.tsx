'use client'
import { useRouter, usePathname, useSearchParams } from 'next/navigation'

const langs = ['en','fr','ru'] as const

export function LanguageSwitcher(){
  const router = useRouter()
  const pathname = usePathname() || '/'
  const sp = useSearchParams()
  const current = sp.get('lang') || 'en'
  return (
    <select
      defaultValue={current}
      onChange={(e)=>{
        const params = new URLSearchParams(sp.toString())
        params.set('lang', e.target.value)
        router.push(`${pathname}?${params.toString()}`)
      }}
      className="text-sm">
      {langs.map(l => <option key={l} value={l}>{l.toUpperCase()}</option>)}
    </select>
  )
}
