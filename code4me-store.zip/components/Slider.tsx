'use client'
import { useEffect, useState } from 'react'

const slides = [
  { title: 'Premium Accounts', subtitle: 'Fresh stock, instant delivery', cta: '/catalog?cat=accounts' },
  { title: 'Programs & Tools', subtitle: 'Downloads with updates', cta: '/catalog?cat=programs' },
  { title: 'Automation Tools', subtitle: 'Boost productivity', cta: '/catalog?cat=tools' },
]

export default function Slider(){
  const [i,setI]=useState(0)
  useEffect(()=>{
    const t = setInterval(()=> setI(x => (x+1)%slides.length), 4000)
    return ()=>clearInterval(t)
  },[])
  const s = slides[i]
  return (
    <div className="card text-center py-16">
      <h2 className="text-3xl font-semibold">{s.title}</h2>
      <p className="text-zinc-400 mt-2">{s.subtitle}</p>
      <a href={s.cta} className="btn mt-4">Shop now</a>
      <div className="mt-6 text-xs text-zinc-500">Slide {i+1}/{slides.length}</div>
    </div>
  )
}
