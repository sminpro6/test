import 'dotenv/config'
import { dbConnect } from '../lib/db'
import Product from '../models/Product'

async function run(){
  await dbConnect()
  const count = await Product.countDocuments()
  if (count>0) { console.log('Already seeded'); process.exit(0) }
  await Product.insertMany([
    { title:'Sample Accounts Pack', slug:'sample-accounts', category:'accounts', priceUSD:5, stockType:'accounts', description:'Sample accounts', productInfo:'Multi-platform', fileFormat:'txt lines', recommendations:'Use proxies' },
    { title:'Example Program', slug:'example-program', category:'programs', priceUSD:12, stockType:'file', downloadableUrl:'https://code4me.org/downloads/example.zip', description:'Program desc', productInfo:'Windows', fileFormat:'zip', recommendations:'Antivirus exclude' }
  ])
  console.log('Seeded.')
  process.exit(0)
}
run()
