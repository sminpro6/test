# code4me-store (Next.js + MongoDB + PM2)

Digital goods shop for **accounts** and **programs/tools** with:
- Catalog, Product page, Cart, Checkout
- USDT (ERC-20) payment by **TX hash** verification
- Multi-language (EN/FR/RU)
- Admin panel: Products CRUD, Orders, upload accounts via CSV/text
- Auto-delivery: N accounts per quantity; files for programs

## Quick start
```bash
cp .env.example .env       # fill values
npm install
npm run build
pm2 start npm --name code4me -- start
pm2 save
```
