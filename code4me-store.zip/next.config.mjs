/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: { allowedOrigins: ['code4me.org', 'www.code4me.org'] }
  },
};
export default nextConfig;
