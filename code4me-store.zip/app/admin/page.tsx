import { requireAdminToken } from '@/lib/auth'
import Link from 'next/link'

export default function AdminHome(){
  const ok = requireAdminToken()
  if (!ok) return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Admin</h1>
      <form action="/admin/login" method="get"><button className="btn">Login</button></form>
    </div>
  )
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Admin</h1>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Link className="card" href="/admin/products">Products</Link>
        <Link className="card" href="/admin/orders">Orders</Link>
        <Link className="card" href="/admin/stock">Upload Accounts</Link>
      </div>
    </div>
  )
}
