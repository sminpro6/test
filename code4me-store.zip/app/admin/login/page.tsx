'use client'
import { useState } from 'react'

export default function Login(){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [msg,setMsg]=useState('')
  async function doLogin(e:any){
    e.preventDefault()
    const res = await fetch('/api/auth/login', {
      method:'POST', headers:{'content-type':'application/json'},
      body: JSON.stringify({ email, password })
    })
    if (res.ok) window.location.href = '/admin'
    else setMsg('Invalid credentials')
  }
  return (
    <div className="max-w-sm mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Admin login</h1>
      {msg && <div className="text-red-400 text-sm">{msg}</div>}
      <form onSubmit={doLogin} className="space-y-3">
        <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="input" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="btn w-full">Login</button>
      </form>
    </div>
  )
}
