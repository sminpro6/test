import { requireAdminToken } from '@/lib/auth'

export default function Stock(){
  const ok = requireAdminToken()
  if (!ok) return <div>Unauthorized</div>
  return (
    <div className="space-y-4 max-w-2xl">
      <h1 className="text-2xl font-semibold">Upload Accounts</h1>
      <form id="f" className="card space-y-3" onSubmit={(e)=>{
        e.preventDefault()
        const fd = new FormData(e.currentTarget as HTMLFormElement)
        fetch('/api/admin/upload-accounts', {
          method: 'POST', headers: {'content-type':'application/json'},
          body: JSON.stringify({ productSlug: fd.get('productSlug'), data: fd.get('data') })
        }).then(r=>r.json()).then((d)=> alert('Inserted: '+d.count) ).catch((e)=> alert(e.message))
      }}>
        <input className="input" name="productSlug" placeholder="product slug" />
        <textarea className="input min-h-[200px]" name="data" placeholder="one account per line: user:pass or JSON"></textarea>
        <button className="btn">Upload</button>
      </form>
    </div>
  )
}
