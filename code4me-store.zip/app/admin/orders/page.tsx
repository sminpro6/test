import { dbConnect } from '@/lib/db'
import Order from '@/models/Order'
import { requireAdminToken } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export default async function Orders(){
  const ok = requireAdminToken()
  if (!ok) return <div>Unauthorized</div>
  await dbConnect()
  const list = await Order.find({}).sort({createdAt:-1}).lean()
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Orders</h1>
      <div className="card overflow-auto">
        <table>
          <thead><tr><th>ID</th><th>Status</th><th>Total</th><th>TX</th><th>Delivered</th><th>Created</th></tr></thead>
          <tbody>
            {list.map((o:any)=>(
              <tr key={o._id}>
                <td className="font-mono text-xs">{String(o._id).slice(-8)}</td>
                <td>{o.status}</td>
                <td>${o.totalUSD.toFixed(2)}</td>
                <td className="font-mono text-xs">{o.txHash?.slice(0,10)}...</td>
                <td className="text-xs">{o.deliveredData? 'yes':'no'}</td>
                <td className="text-xs">{new Date(o.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
