import { dbConnect } from '@/lib/db'
import Product from '@/models/Product'
import { requireAdminToken } from '@/lib/auth'

export const dynamic = 'force-dynamic'

export default async function AdminProducts(){
  const ok = requireAdminToken()
  if (!ok) return <div>Unauthorized</div>
  await dbConnect()
  const list = await Product.find({}).sort({createdAt:-1}).lean()
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Products</h1>
      <form action="/api/products" method="post" className="card grid grid-cols-1 sm:grid-cols-2 gap-3">
        <input name="title" placeholder="Title" className="input" />
        <input name="slug" placeholder="slug" className="input" />
        <select name="category">
          <option value="accounts">accounts</option>
          <option value="programs">programs</option>
          <option value="tools">tools</option>
        </select>
        <input name="priceUSD" placeholder="Price USD" className="input" />
        <select name="stockType">
          <option value="accounts">accounts</option>
          <option value="file">file</option>
        </select>
        <input name="downloadableUrl" placeholder="Download URL (for file type)" className="input" />
        <textarea name="description" placeholder="Description" className="input"></textarea>
        <textarea name="productInfo" placeholder="Product information" className="input"></textarea>
        <textarea name="fileFormat" placeholder="File format" className="input"></textarea>
        <textarea name="recommendations" placeholder="Recommendations" className="input"></textarea>
        <button className="btn">Create</button>
      </form>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {list.map((p:any)=> (
          <div className="card" key={p._id}>
            <div className="font-semibold">{p.title}</div>
            <div className="text-sm text-zinc-400">{p.slug}</div>
            <div className="mt-2">${p.priceUSD.toFixed(2)}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
