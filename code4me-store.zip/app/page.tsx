import Slider from '@/components/Slider'
import Link from 'next/link'

export default function Home(){
  return (
    <div className="space-y-10">
      <Slider />
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Link href="/catalog?cat=accounts" className="card">Accounts</Link>
        <Link href="/catalog?cat=programs" className="card">Programs</Link>
        <Link href="/catalog?cat=tools" className="card">Tools</Link>
      </section>
    </div>
  )
}
