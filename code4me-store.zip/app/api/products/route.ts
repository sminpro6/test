import { dbConnect } from '@/lib/db'
import Product from '@/models/Product'

export async function GET(req: Request){
  await dbConnect()
  const { searchParams } = new URL(req.url)
  const slug = searchParams.get('slug')
  if (slug){
    const p = await Product.findOne({ slug }).lean()
    return Response.json(p)
  }
  const products = await Product.find({}).sort({ createdAt: -1 }).lean()
  return Response.json(products)
}

export async function POST(req: Request){
  await dbConnect()
  const body = await req.json()
  const p = await Product.create(body)
  return Response.json({ ok:true, product: p })
}
