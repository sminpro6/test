import { dbConnect } from '@/lib/db'
import StockItem from '@/models/StockItem'
import { requireAdminToken } from '@/lib/auth'

export async function POST(req: Request){
  if (!requireAdminToken()) return new Response('Unauthorized', { status: 401 })
  await dbConnect()
  const { productSlug, data } = await req.json()
  const lines = (data as string).split(/\r?\n/).map(l=>l.trim()).filter(Boolean)
  await StockItem.insertMany(lines.map(value => ({ productSlug, value })))
  return Response.json({ ok:true, count: lines.length })
}
