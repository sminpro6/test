import { dbConnect } from '@/lib/db'
import Order from '@/models/Order'
import Product from '@/models/Product'
import StockItem from '@/models/StockItem'
import { verifyUsdtPaymentByTx } from '@/lib/usdt'

export async function POST(req: Request){
  try{
    await dbConnect()
    const { items, totalUSD, txHash, email } = await req.json()

    // Validate items & compute expected
    const slugs = items.map((i:any)=>i.slug)
    const dbProducts = await Product.find({ slug: { $in: slugs } }).lean()
    const sum = items.reduce((sum:number, i:any)=>{
      const p = dbProducts.find(d=>d.slug===i.slug)
      return sum + (p? p.priceUSD * i.quantity : 0)
    },0)

    if (Math.abs(sum - totalUSD) > 0.01) {
      return Response.json({ ok:false, message: 'Total mismatch' }, { status: 400 })
    }

    // Create pending order
    const order = await Order.create({
      items: items.map((i:any)=>{
        const p = dbProducts.find(d=>d.slug===i.slug)!
        return { productSlug: i.slug, title: p.title, quantity: i.quantity, unitPriceUSD: p.priceUSD }
      }),
      totalUSD: sum,
      status: 'pending',
      txHash: txHash || '',
      email: email || ''
    })

    // If tx provided, try verify (non-blocking)
    if (txHash) {
      queueMicrotask(async () => {
        try{
          const usdRate = 1.0 // simplify; could fetch live FX later if needed
          const expectedUsdt = sum / usdRate
          const res = await verifyUsdtPaymentByTx(txHash, expectedUsdt)
          if (res.ok){
            // deliver
            let delivered = ''
            for (const it of order.items){
              const p = dbProducts.find(d=>d.slug===it.productSlug)!
              if (p.stockType === 'accounts'){
                const stock = await StockItem.find({ productSlug: p.slug, used: false }).limit(it.quantity)
                if (stock.length < it.quantity) continue
                delivered += `\n# ${p.title} x${it.quantity}\n`
                for (const s of stock){
                  delivered += s.value + '\n'
                  s.used = True
                  await s.save()
                }
              } else if (p.stockType === 'file'){
                delivered += `\n# ${p.title}: ${p.downloadableUrl}\n`
              }
            }
            order.status = 'paid'
            order.deliveredData = delivered.trim()
            await order.save()
          }
        }catch(e){ console.error('verify/deliver error', e) }
      })
    }

    return Response.json({ ok:true, message: 'Order created. If you provided TX hash, we will verify and deliver soon.' })
  }catch(e:any){
    return Response.json({ ok:false, message: e.message || 'Error' }, { status: 500 })
  }
}
