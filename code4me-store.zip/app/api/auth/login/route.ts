import { login } from '@/lib/auth'

export async function POST(req: Request){
  const { email, password } = await req.json()
  const res = await login(email, password)
  if (!res) return Response.json({ ok:false, message: 'Invalid credentials' }, { status: 401 })
  return Response.json({ ok:true })
}
