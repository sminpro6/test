'use client'
import { useEffect, useState } from 'react'

type Item = { slug:string, title:string, quantity:number, unitPriceUSD:number }

export default function Cart(){
  const [items,setItems]=useState<Item[]>([])
  useEffect(()=>{
    const raw = localStorage.getItem('cart')
    setItems(raw?JSON.parse(raw):[])
  },[])
  const total = items.reduce((a,b)=>a+b.quantity*b.unitPriceUSD,0)

  function remove(slug:string){
    const n = items.filter(i=>i.slug!==slug)
    setItems(n); localStorage.setItem('cart', JSON.stringify(n))
  }
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Cart</h1>
      {items.length===0 && <div className="text-zinc-400">Cart is empty.</div>}
      {items.map(i=> (
        <div key={i.slug} className="card flex items-center justify-between">
          <div>
            <div className="font-semibold">{i.title}</div>
            <div className="text-sm text-zinc-400">x{i.quantity} @ ${i.unitPriceUSD.toFixed(2)}</div>
          </div>
          <button className="btn" onClick={()=>remove(i.slug)}>Remove</button>
        </div>
      ))}
      {items.length>0 && (
        <div className="mt-6 space-y-3">
          <div className="text-xl font-bold">Total: ${total.toFixed(2)}</div>
          <a className="btn" href="/checkout">Proceed to Checkout</a>
        </div>
      )}
    </div>
  )
}
