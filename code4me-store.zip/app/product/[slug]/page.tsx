import { dbConnect } from '@/lib/db'
import Product from '@/models/Product'
import Link from 'next/link'

export default async function ProductPage({ params }:{ params: { slug:string }}){
  await dbConnect()
  const p = await Product.findOne({ slug: params.slug }).lean()
  if(!p) return <div>Not found</div>
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="card">Image</div>
      <div className="space-y-4">
        <h1 className="text-2xl font-semibold">{p.title}</h1>
        <div className="text-zinc-400 capitalize">{p.category}</div>
        <div className="text-3xl font-bold">${p.priceUSD.toFixed(2)}</div>

        <form action="/cart" method="post" className="space-x-2">
          <input type="hidden" name="slug" value={p.slug} />
          <label>Quantity</label>
          <input className="input w-24" type="number" min="1" defaultValue={1} name="qty" />
          <button className="btn">Add to cart</button>
        </form>

        <div className="card">
          <h3 className="font-semibold mb-1">Description</h3>
          <p className="text-sm text-zinc-300 whitespace-pre-wrap">{p.description || '—'}</p>
        </div>
        <div className="card">
          <h3 className="font-semibold mb-1">Product information</h3>
          <p className="text-sm text-zinc-300 whitespace-pre-wrap">{p.productInfo || '—'}</p>
        </div>
        <div className="card grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <h3 className="font-semibold mb-1">File format</h3>
            <p className="text-sm text-zinc-300 whitespace-pre-wrap">{p.fileFormat || '—'}</p>
          </div>
          <div>
            <h3 className="font-semibold mb-1">Recommendations</h3>
            <p className="text-sm text-zinc-300 whitespace-pre-wrap">{p.recommendations || '—'}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
