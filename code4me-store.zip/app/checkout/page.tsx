'use client'
import { useEffect, useState } from 'react'

export default function Checkout(){
  const [items,setItems]=useState<any[]>([])
  const [tx,setTx]=useState('')
  const [email,setEmail]=useState('')
  const [placing,setPlacing]=useState(false)
  const total = items.reduce((a,b)=>a+b.quantity*b.unitPriceUSD,0)

  useEffect(()=>{
    const raw = localStorage.getItem('cart')
    setItems(raw?JSON.parse(raw):[])
  },[])

  async function placeOrder(){
    setPlacing(true)
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'content-type':'application/json' },
      body: JSON.stringify({ items, totalUSD: total, txHash: tx, email })
    })
    const data = await res.json()
    setPlacing(false)
    if (data.ok){
      alert('Order placed! ' + data.message)
      localStorage.removeItem('cart')
      window.location.href = '/'
    } else {
      alert('Error: ' + data.message)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Checkout</h1>
      <div className="card">
        <div className="text-sm text-zinc-400">Send USDT (ERC-20) to:</div>
        <div className="font-mono mt-1">0x2b5779e797c6c5d272380386a46136f3c6104540</div>
      </div>
      <div className="card grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block mb-1">Email (for delivery)</label>
          <input className="input" value={email} onChange={e=>setEmail(e.target.value)} />
        </div>
        <div>
          <label className="block mb-1">USDT Transaction Hash (after payment)</label>
          <input className="input" value={tx} onChange={e=>setTx(e.target.value)} placeholder="0x..." />
        </div>
      </div>
      <button disabled={placing} onClick={placeOrder} className="btn">{placing?'Placing...':'Place order'}</button>
    </div>
  )
}
