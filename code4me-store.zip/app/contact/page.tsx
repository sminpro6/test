export default function Contact(){
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Contact</h1>
      <div className="card">
        <div>Telegram: <a className="text-blue-400" href="https://t.me/arkoselabes" target="_blank">https://t.me/arkoselabes</a></div>
        <div>Email: admin@code4me.org</div>
      </div>
    </div>
  )
}
