import { dbConnect } from '@/lib/db'
import Product from '@/models/Product'
import { ProductCard } from '@/components/ProductCard'

export const dynamic = 'force-dynamic'

export default async function Catalog({ searchParams }:{ searchParams: { q?:string, cat?:string }}){
  await dbConnect()
  const q = searchParams.q || ''
  const cat = searchParams.cat
  const filter:any = {}
  if (q) filter.title = { $regex: q, $options: 'i' }
  if (cat) filter.category = cat
  const products = await Product.find(filter).sort({ createdAt: -1 }).lean()
  return (
    <div className="space-y-6">
      <form className="flex gap-2">
        <input className="input" name="q" placeholder="Search products..." defaultValue={q} />
        <select name="cat">
          <option value="">All</option>
          <option value="accounts" selected={cat==='accounts'}>Accounts</option>
          <option value="programs" selected={cat==='programs'}>Programs</option>
          <option value="tools" selected={cat==='tools'}>Tools</option>
        </select>
        <button className="btn" type="submit">Search</button>
      </form>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {products.map((p:any)=>(<ProductCard key={p._id} p={p} />))}
      </div>
    </div>
  )
}
